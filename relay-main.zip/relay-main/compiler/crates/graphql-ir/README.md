# graphql_ir

Strongly typed intermediate representation (IR) for GraphQL.
