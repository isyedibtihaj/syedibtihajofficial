# graphql_syntax

Lexer, parser, and CST (concrete syntax tree) for the executable subset of GraphQL syntax.

## Development

Note that snapshots can be updated by running tests with the `UPDATE_SNAPSHOTS=1` environment variable set.
